from Unit import Unit
from Infantry import Infantry
from Tank import Tank
from Helicopter import Helicopter

'''
The purpose of the base is to spawn units during gameplay.
'''
class Base(Unit):
    '''initializr'''
    def __init__(self, x, y, base):
        # if base, set health to 5
        if(base):
            Unit.__init__(self, 0, 5, 0, 1, 0, x, y)
        # if camp, set health to 3
        else:
            Unit.__init__(self, 1, 3, 0, 1, 0, x, y)
        self.isBase = base

    # differentiates bases from camps
    def isBase(self):
        '''checks the type of the base and returns boolean'''
        return self.isBase

    # camps can only spawn infantry
    def spawnUnit(self, unitType, x, y):
        '''base spawns unit at position'''
        if self.isBase:
            if unitType == 2:
                unit = Infantry(x, y)
            elif unitType == 3:
                unit = Tank(x, y)
            else:
                unit = Helicopter(x, y)
        else:
            unit = Infantry(x, y)
        return unit
