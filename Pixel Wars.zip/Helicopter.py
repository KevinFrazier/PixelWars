from tkinter import *
from Unit import Unit
'''
the helicopter is a subclass of unit. Its main difference between the other unit subclass is that it can move through
all tiles while infantry and tank are affected by water and mountain
'''
class Helicopter(Unit):
    # type, health, damage, movement, range, x, y
    def __init__(self, x, y):
        ''' initializer '''
        Unit.__init__(self, 4, 5, 3, 2, 1, x, y)
        self.ignoreTiles = (2, 4) #water, mountain sprites

    def move(self, x, y):
        ''' moves the helicopter to the specified position'''
        if self.getRemainingMoves() > 0:
            difX = abs(self.getX() - x)
            difY = abs(self.getY() - y)
            reqMoves = difX + difY
            if reqMoves > self.getRemainingMoves():
                return False
            else:
                self.setX(x)
                self.setY(y)
                self.setRemainingMoves(self.getRemainingMoves() - reqMoves)
                return True

    def checkIgnoredTiles(self):
        ''' returns the type of the tiles that helicopter ignores'''
        return self.ignoreTiles

    def attack(self, otherUnit):
        ''' attack command to other Units'''
        if self.getRemainingMoves() > 0:
            if self.calcAdvantage(otherUnit): #function to determine the type advantage between units
                dmg = self.getDamage() * 2
            else:
                dmg = self.getDamage()
            if otherUnit.getHealth() <= dmg:
                return True
            else:
                otherUnit.setHealth(otherUnit.getHealth() - dmg)
                return False
