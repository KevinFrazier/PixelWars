from tkinter import *
from tkinter import messagebox
from theMap import Map
from Player import Player
from Unit import Unit
from Infantry import Infantry
from Tank import Tank
from Helicopter import Helicopter
from Base import Base
from threading import Timer
import math

'''The game is the interface for the user and it connects the Player and Map classes together. The purpose is to pass the
 arguments of the user to make the appropriate map. Then calls the functions of the map and the player to coordinate the
 gameplay'''

root = Tk()
class Game(Frame):

    def __init__(self):
        '''initializer '''
        self.titleMenu()

    def updateMap(self):
        '''updates the map by redrawing the units in the unit grid'''
        for player in self.listOfPlayers:
            for unit in player.unitList:
                self.map.drawImage(player.playerNumber, unit.getX(), unit.getY(), unit.getType())

    def UserButtons(self):
        '''creates the buttons of the interface'''
        buttonFrame = Frame(self)
        buttonFrame.grid()
        self.upButton = Button(buttonFrame, text=" ^ ", command=self.up)
        self.upButton.grid(row=0, column=1)
        self.downButton = Button(buttonFrame, text=" v ", command=self.down)
        self.downButton.grid(row=2, column=1)
        self.leftButton = Button(buttonFrame, text=" < ", command=self.left)
        self.leftButton.grid(row=1, column=0)
        self.rightButton = Button(buttonFrame, text=" > ", command=self.right)
        self.rightButton.grid(row=1, column=2)

        self.spawnButton = Button(buttonFrame, text="Spawn Unit", command=self.spawn)
        self.spawnButton.grid(row=0, column=5)
        self.infantryRdo = Radiobutton(buttonFrame, text="Infantry", variable=self.spawnUnitType, value=2)
        self.infantryRdo.grid(row=1, column=5)
        self.tankRdo = Radiobutton(buttonFrame, text="Tank", variable=self.spawnUnitType, value=3)
        self.tankRdo.grid(row=2, column=5)
        self.helicopterRdo = Radiobutton(buttonFrame, text="Helicopter", variable=self.spawnUnitType, value=4)
        self.helicopterRdo.grid(row=3, column=5)

        self.attackButton = Button(buttonFrame, text = "Attack", command = self.attack)
        self.attackButton.grid(row = 1,column =6)
        cancelButton = Button(buttonFrame, text="Cancel", command=self.cancel)
        cancelButton.grid(row=2, column=6)
        skipButton = Button(buttonFrame, text="Skip", command=self.skip)
        skipButton.grid(row=3, column=6)

    def skip(self):
        '''skips the current units turn'''
        try:
            u = self.currentPlayer.getCurrentUnit()
            if not u.canMove():
                print("skip old unit", u)
                self.currentPlayer.nextUnit()
                self.skip()
            else:
                print("skip new unit")
                self.currentPlayer.nextUnit()
                try:
                    u = self.currentPlayer.getCurrentUnit()
                except IndexError:
                    self.switchPlayers()
                    self.currentPlayer.newTurn()
        except IndexError:
            print("already OOB")
            self.switchPlayers()
            self.currentPlayer.newTurn()

    def getPlayer_getUnit(self, x, y):
        '''gets the unit of the position and the player is corresponds too'''
        for player in self.listOfPlayers:
                for u in player.unitList:
                    if u.getX() == x and u.getY() == y:
                        return u,player

        return None

    def attack(self):
        '''trigger for the attack button '''
        s = self.currentPlayer.getCurrentUnit() #current unit
        if s.getType() != 0 and s.getType() != 1: #if not a base and not a camp

            if not (self.attackButtonPressed): #if the attack button was not pressed

                self.cursorPositionX = s.getX()
                self.cursorPositionY = s.getY()
                self.redrawCursor()
                #change position of cursor
                #change button commands
                self.upButton.configure(command=self.attackUp)
                self.downButton.configure(command=self.attackDown)
                self.rightButton.configure(command=self.attackRight)
                self.leftButton.configure(command=self.attackLeft)

                #indicate attack button was pressed
                self.attackButtonPressed = True

            else:

                # get opposing unit
                if self.map._unitGrid[self.cursorPositionX][self.cursorPositionY] != None:
                    u, p = self.getPlayer_getUnit(self.cursorPositionX, self.cursorPositionY)
                    if u is s: #if the unit targets himself
                        print("CANNOT SHOOT YOURSELF")
                        return
                    if p == self.currentPlayer: #if a friendly unit is targets
                        print("NO FRIENDLY FIRE")
                        return

                    # change button commands
                    # calculate damage
                    # identify unit being attacked, and attack, then check the life if it is zero then delete image
                    # when the attacked unit is dead
                    distance = int(abs(s.getX() - u.getX()) + abs(s.getY() - u.getY()))
                    print("distance: ", distance)
                    print("s range: ", s.getRange())
                    if s.getRange() >= distance: #check if units in range
                        if s.attack(u): #s unit attacks u unit. If true -> u unit is dead
                            print("opping unit is dead")
                            if u.getType() == 0: #if the opponents base is destroyed.. you win!
                                # win
                                print("win")
                                messagebox.showinfo("WINNER!","Player " + str(self.currentPlayer.playerNumber) + "wins!")

                                self.map._unitGrid[u.getX()][u.getY()] = None
                                p.removeUnit(u)

                        else:
                            print("opposing unit health: ", u.getHealth())

                        #change buttons
                        self.upButton.configure(command=self.up)
                        self.downButton.configure(command=self.down)
                        self.rightButton.configure(command=self.right)
                        self.leftButton.configure(command=self.left)
                        self.attackButtonPressed = False

                    else:
                        print("invalid target, target is at distance of: ", distance, " and range is: ", s.getRange())
                        return
                else:
                    print("cursor pointing at nothing")
                    return

                #redraw
                self.map.draw_grid()

                # end Unit's turn
                #rotates turns
                try:
                    self.currentPlayer.nextUnit()
                except IndexError:
                    self.switchPlayers()
                    self.currentPlayer.newTurn()

    def cancel(self):
        '''cancels the attack '''

        #changes button commands
        self.upButton.configure(command=self.up)
        self.downButton.configure(command=self.down)
        self.rightButton.configure(command=self.right)
        self.leftButton.configure(command=self.left)

        # change self.attackButton state and delete Cursor
        self.attackButtonPressed = False
        c = self.map._screen
        c.delete("cursor")

    def redrawCursor(self):
        '''redraws the cursor '''
        c = self.map._screen
        # print(c.find_withtag( "cursor" ))
        c.delete("cursor")
        item = c.create_image((self.cursorPositionX * self.map.spriteDimension, self.cursorPositionY * self.map.spriteDimension),
                       anchor = NW , image = self.cursor)
        c.itemconfig(item, tags = "cursor") #creates a tag for the cursor in order to delete

    def attackUp(self):
        '''move cursor up'''
        self.cursorPositionY =  self.cursorPositionY - 1
        self.redrawCursor()

    def attackRight(self):
        '''move cursor right'''
        self.cursorPositionX = self.cursorPositionX + 1
        self.redrawCursor()

    def attackDown(self):
        '''move cursor right'''
        self.cursorPositionY = self.cursorPositionY + 1
        self.redrawCursor()

    def attackLeft(self):
        '''attack left '''
        self.cursorPositionX = self.cursorPositionX - 1
        self.redrawCursor()

    def up(self):
        '''move current unit up'''

        ''' summary: each movement check for different type of units and terrain'''
        try:
            u = self.currentPlayer.getCurrentUnit()
            if u.canMove():
                if u.getType() != 0 and u.getType() != 1:
                    if self.map.checkInbound(u.getX(), u.getY() - 1):
                        if self.map._grid[u.getX()][u.getY() - 1].isAvailable():
                            if self.map._grid[u.getX()][u.getY() - 1].getTileType() == 2 or self.map._grid[u.getX() + 1][u.getY()].getTileType() == 4:
                                if u.getType() == 4:
                                    self.map._unitGrid[u.getX()][u.getY() - 1] = self.map._unitGrid[u.getX()][u.getY()]
                                    self.map._unitGrid[u.getX()][u.getY()] = None
                                    self.map._grid[u.getX()][u.getY()].setAvailable(True)
                                    u.move(u.getX(), u.getY() - 1)
                                    self.map.draw_grid()
                            else:
                                self.map._unitGrid[u.getX()][u.getY() - 1] = self.map._unitGrid[u.getX()][u.getY()]
                                self.map._unitGrid[u.getX()][u.getY()] = None
                                self.map._grid[u.getX()][u.getY()].setAvailable(True)
                                u.move(u.getX(), u.getY() - 1)
                                self.map.draw_grid()
                        else:
                            print("not available")
            else:
                self.currentPlayer.nextUnit()
                self.up()
        except IndexError:
            self.switchPlayers()
            self.currentPlayer.newTurn()
            self.up()

    def down(self):
        '''moves current unit down'''
        try:
            u = self.currentPlayer.getCurrentUnit()
            if u.canMove():
                if u.getType() != 0 and u.getType() != 1:
                    if self.map.checkInbound(u.getX(), u.getY() + 1):
                        if self.map._grid[u.getX()][u.getY() + 1].isAvailable():
                            if self.map._grid[u.getX()][u.getY() + 1].getTileType() == 2 or self.map._grid[u.getX() + 1][u.getY()].getTileType() == 4:
                                if u.getType() == 4:
                                    self.map._unitGrid[u.getX()][u.getY() + 1] = self.map._unitGrid[u.getX()][u.getY()]
                                    self.map._unitGrid[u.getX()][u.getY()] = None
                                    self.map._grid[u.getX()][u.getY()].setAvailable(True)
                                    u.move(u.getX(), u.getY() + 1)
                                    self.map.draw_grid()
                            else:
                                self.map._unitGrid[u.getX()][u.getY() + 1] = self.map._unitGrid[u.getX()][u.getY()]
                                self.map._unitGrid[u.getX()][u.getY()] = None
                                self.map._grid[u.getX()][u.getY()].setAvailable(True)
                                u.move(u.getX(), u.getY() + 1)
                                self.map.draw_grid()
                        else:
                            print("not available")
            else:
                self.currentPlayer.nextUnit()
                self.down()
        except IndexError:
            self.switchPlayers()
            self.currentPlayer.newTurn()
            self.down()

    def left(self):
        '''move current unit left'''
        try:
            u = self.currentPlayer.getCurrentUnit()
            if u.canMove():
                if u.getType() != 0 and u.getType() != 1:
                    if self.map.checkInbound(u.getX() - 1, u.getY()):
                        if self.map._grid[u.getX() - 1][u.getY()].isAvailable():
                            if self.map._grid[u.getX() - 1][u.getY()].getTileType() == 2 or self.map._grid[u.getX() + 1][u.getY()].getTileType() == 4:
                                if u.getType() == 4:
                                    self.map._unitGrid[u.getX() - 1][u.getY()] = self.map._unitGrid[u.getX()][u.getY()]
                                    self.map._unitGrid[u.getX()][u.getY()] = None
                                    self.map._grid[u.getX()][u.getY()].setAvailable(True)
                                    u.move(u.getX() - 1, u.getY())
                                    self.map.draw_grid()
                            else:
                                self.map._unitGrid[u.getX() - 1][u.getY()] = self.map._unitGrid[u.getX()][u.getY()]
                                self.map._unitGrid[u.getX()][u.getY()] = None
                                self.map._grid[u.getX()][u.getY()].setAvailable(True)
                                u.move(u.getX() - 1, u.getY())
                                self.map.draw_grid()
                        else:
                            print("not available")
            else:
                self.currentPlayer.nextUnit()
                self.left()
        except IndexError:
            self.switchPlayers()
            self.currentPlayer.newTurn()
            self.left()

    def right(self):
        ''' moves current unit right'''
        try:
            u = self.currentPlayer.getCurrentUnit()
            if u.canMove():
                if u.getType() != 0 and u.getType() != 1:
                    if self.map.checkInbound(u.getX() + 1, u.getY()):
                        if self.map._grid[u.getX() + 1][u.getY()].isAvailable():
                            if self.map._grid[u.getX() + 1][u.getY()].getTileType() == 2 or self.map._grid[u.getX() + 1][u.getY()].getTileType() == 4:
                                if u.getType() == 4:
                                    self.map._unitGrid[u.getX() + 1][u.getY()] = self.map._unitGrid[u.getX()][u.getY()]
                                    self.map._unitGrid[u.getX()][u.getY()] = None
                                    self.map._grid[u.getX()][u.getY()].setAvailable(True)
                                    u.move(u.getX() + 1, u.getY())
                                    self.map.draw_grid()
                            else:
                                self.map._unitGrid[u.getX() + 1][u.getY()] = self.map._unitGrid[u.getX()][u.getY()]
                                self.map._unitGrid[u.getX()][u.getY()] = None
                                self.map._grid[u.getX()][u.getY()].setAvailable(True)
                                u.move(u.getX() + 1, u.getY())
                                self.map.draw_grid()
                        else:
                            print("not available")
            else:
                self.currentPlayer.nextUnit()
                self.right()
        except IndexError:
            self.switchPlayers()
            self.currentPlayer.newTurn()
            self.right()

    def switchPlayers(self):
        ''' rotate players'''
        if self.currentPlayer == self.listOfPlayers[0]:
            self.currentPlayer = self.listOfPlayers[1]
        else:
            self.currentPlayer = self.listOfPlayers[0]
        # self.enableDisableButtons()

    def titleMenu(self):
        '''creates a title menu'''
        Frame.__init__(self)
        self.pack()
        self.menuFrame = Frame(self)
        self.menuFrame.pack()

        titleLabel = Label(self.menuFrame, text = "Pixel Wars")
        titleLabel.pack(anchor=CENTER)

        playerFrame = Frame(self, borderwidth = 10)
        playerFrame.pack(anchor=CENTER)
        MapFrame = Frame(self.menuFrame)
        MapFrame.pack()

        self.mapLabel = Label(MapFrame, text="Map")
        self.mapLabel.pack()
        self.var3 = IntVar()
        R42 = Radiobutton(MapFrame, text="S", variable=self.var3, value=10, command=self.sel2)
        R42.pack(anchor=W, side=LEFT)
        R52 = Radiobutton(MapFrame, text="M", variable=self.var3, value=20, command=self.sel2)
        R52.pack(anchor=W, side=LEFT)
        R62 = Radiobutton(MapFrame, text="L", variable=self.var3, value=30, command=self.sel2)
        R62.pack(anchor=W, side=LEFT)

        startFrame = Frame(self)
        startFrame.pack()

        startButton = Button(startFrame, text = "Start", command = self.start)
        startButton.pack()
        exitButton = Button(startFrame, text = "Exit", command = self.exit)
        exitButton.pack()

    def start(self):
        # self.titleMenu()
        # self.gameFrame = Frame(self.)
        print(self.var3.get())
        if self.var3.get() != 0:
            self.master.destroy()
            Frame.__init__(self)
            self.pack()

            self.listOfPlayers = [Player(0), Player(1)]
            self.currentPlayer = self.listOfPlayers[0]

            self.map = Map(self.var3.get())

            self.cursor = PhotoImage(file="cursor.gif")
            c = self.map._screen
            self.cursorPositionX = 0
            self.cursorPositionY = 0
            self.attackButtonPressed = False

            #random function
            self.aUnit = Base(1, 1, 1)
            self.bUnit = Base(self.var3.get()-2, self.var3.get()- 2, 1)
            self.listOfPlayers[0].addUnit(self.aUnit)
            self.listOfPlayers[1].addUnit(self.bUnit)

            self.spawnUnitType = IntVar()
            self.UserButtons()
            # self.enableDisableButtons()
            self.updateMap()  # for units only
            self.map.fill()
            self.map.draw_grid()

    def exit(self):
        #destroy game frame
        self.master.destroy()
        return

    def sel2(self):
        '''gets the value of the map inputted by the user'''
        print("You have selected Map: " + str(self.var3.get()))


    def spawn(self):
        '''spawns a unit at a random tile'''

        '''summary:

        checks if the current unit is a bse or camp
        ;get all adjacent tiles around the base or camp
        spawns unit while checking for types of unit and terrains

        '''
        try:
            u = self.currentPlayer.getCurrentUnit()
            if u.canMove():
                if u.getType() == 0 or u.getType() == 1:
                    for tile in self.map.getAdjacent(self.currentPlayer.getCurrentUnit().getX(),
                                                     self.currentPlayer.getCurrentUnit().getY()):
                        if tile.isAvailable():
                            if tile.getTileType() == 2 or tile.getTileType() == 4:
                                if self.spawnUnitType.get() == 4:
                                    unit = u.spawnUnit(self.spawnUnitType.get(), tile.getX(), tile.getY())
                                    unit.setRemainingMoves(0)
                                    self.currentPlayer.addUnit(unit)
                                    self.updateMap()
                                    self.currentPlayer.getCurrentUnit().setRemainingMoves(
                                        self.currentPlayer.getCurrentUnit().getRemainingMoves() - 1)
                                    return True
                            else:
                                unit = u.spawnUnit(self.spawnUnitType.get(), tile.getX(), tile.getY())
                                unit.setRemainingMoves(0)
                                self.currentPlayer.addUnit(unit)
                                self.updateMap()
                                self.currentPlayer.getCurrentUnit().setRemainingMoves(
                                    self.currentPlayer.getCurrentUnit().getRemainingMoves() - 1)
                                return True
                elif u.getType() == 2:
                    for tile in self.map.getAdjacent(self.currentPlayer.getCurrentUnit().getX(),
                                                     self.currentPlayer.getCurrentUnit().getY()):
                        if tile.isAvailable():
                            if tile.getTileType() != 2 and tile.getTileType() != 4:
                                unitX, unitY, unitType = u.buildCamp(tile.getX(), tile.getY())
                                unit = Base(unitX, unitY, unitType)
                                unit.setRemainingMoves(0)
                                self.currentPlayer.addUnit(unit)
                                self.updateMap()
                                self.currentPlayer.getCurrentUnit().setRemainingMoves(
                                    self.currentPlayer.getCurrentUnit().getRemainingMoves() - 1)
                                return True
            else:
                self.currentPlayer.nextUnit()
                self.spawn()
                # self.enableDisableButtons()
        except IndexError:
            self.switchPlayers()
            self.currentPlayer.newTurn()
            # self.enableDisableButtons()
            self.spawn()

def main():
    PixelWars = Game()
    # root.after(1000,Game.updateMap)
    root.mainloop() # forever loop

main()
