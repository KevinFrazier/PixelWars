from tile import Tile
import random, time
from tkinter import *

'''
The purpose of the map is to keep track of two grids- the unit grid and the tile grid. This is where they are drawn/redrawn"
The map is randomly generate to create versality with every matched played by the user/
'''

class Map(Frame):
    def __init__(self, size):
        '''initializer '''
        Frame.__init__(self)
        self.pack()

        #images must keep a reference of the images or they will disappear in the canvas widget
        #cursor
        self.cursor = PhotoImage(file="cursor.gif")
        #terrain
        self.spriteDimension = 20
        self.grass = PhotoImage(file = "grass.gif")
        self.water1 = PhotoImage(file = "water.gif")
        self.street = PhotoImage(file = "street.gif")
        self.mountain = PhotoImage(file = "mountain.gif")

        # player 1 units
        self.infantry1 = PhotoImage(file= "infantry.gif")
        self.tank1 = PhotoImage(file="tank.gif")
        self.helicopter1 = PhotoImage(file="helicopter.gif")
        self.base1 = PhotoImage(file="base.gif")
        self.camp1 = PhotoImage(file="camp.gif")
        # player 2 units
        self.infantry2 = PhotoImage(file="infantry2.gif")
        self.tank2 = PhotoImage(file="tank2.gif")
        self.helicopter2 = PhotoImage(file="helicopter2.gif")
        self.base2 = PhotoImage(file="base2.gif")
        self.camp2 = PhotoImage(file="camp2.gif")
        self.imageList = [[self.base1, self.camp1, self.infantry1, self.tank1, self.helicopter1],
                          [self.base2, self.camp2, self.infantry2, self.tank2, self.helicopter2]]

        #size of map
        self._mapSize = size
        #randomized tile grid of map
        self._grid = self.randomize()
        #unit grid of map
        self._unitGrid = self.allocate(None)

        canvas_dimension = self._mapSize * self.spriteDimension

        #canvas widget -> to print
        self._screen = Canvas(self, width=canvas_dimension, height=canvas_dimension)
        self._screen.pack()

        #draw grids
        self.draw_grid()

    def draw_grid(self):
        #traverses through the unit grid and the tile grid and draws ther images

        self._screen.delete("all") #clear canvas widget
        for vertical in self._grid:
            for horizontal in vertical:

                    self._screen.create_image((int(horizontal.getX() * self.spriteDimension),
                                               int(horizontal.getY() * self.spriteDimension)), anchor=NW,
                                              image=horizontal.getSprite())

        for x in range(self._mapSize):
            for y in range(self._mapSize):
                if self._unitGrid[x][y] != None:
                    self._screen.create_image((x* self.spriteDimension,
                                               y * self.spriteDimension), anchor=NW,
                                              image=self._unitGrid[x][y])
                    

    def drawImage(self, playerNumber, x, y, type):
        ''' draw unit into the unit grid with the given player number and position'''
        item = self._screen.create_image((x*self.spriteDimension, y*self.spriteDimension),anchor = NW, image = (self.imageList[playerNumber][type]))
        self._unitGrid[x][y] = self.imageList[playerNumber][type]
        self._grid[x][y].setAvailable(False)

    def checkUniGridAvailability(self, x,y):
        ''' checks the position of the unitgrid and returns availability'''
        if self._unitGrid[x][y] != None:
            return False
        return True

    def checkTileGridAvailability(self,x,y):
        ''' checks the position of the tile grid and returns avail.'''
        if self._grid[x][y] != None:
            return False
        return True

    #takes care of the terrain: grass, water
    def randomize(self):
        ''' randomizes the map with grass and water'''
        t = self.allocate(Tile)

    # 1- grass, 2- water, 3- street, 4- mountain
        for vertical in range(self._mapSize):
            for horizontal in range(self._mapSize):
                t[vertical][horizontal].setTileType(1)
                t[vertical][horizontal].setPosition(vertical,horizontal)
                t[vertical][horizontal].setSprite(self.grass)
        return t

    def fill(self):
        '''creates the behavior of the street and mountain'''
        unitList = []
        for x in range(0,int(self._mapSize)):
            for y in range(self._mapSize):
                if self._unitGrid[x][y] != None:
                    unitList.append([x,y])

        P1 = unitList[0] #x,y
        P2 = unitList[1]

        n = self._mapSize
        n = int(n)
        for x in range(0,n*3):
            W1 = random.randint(0, self._mapSize-1)
            W2 = random.randint(0, self._mapSize-1)
            while self._grid[W1][W2].getTileType() == 2 or self._grid[W1][W2].getTileType() == 4:
                W1 = random.randint(P1[0] + 1, P2[0] - 1)
                W2 = random.randint(P1[0] + 1, P2[0] - 1)

            self._grid[W1][W2] = Tile(W1, W2, 2)
            self._grid[W1][W2].setSprite(self.water1)

        for x in range(0,n*2):
            W1 = random.randint(P1[0] + 1, P2[0] - 1)
            W2 = random.randint(P1[0] + 1, P2[0] - 1)
            while self._grid[W1][W2].getTileType() == 2 or self._grid[W1][W2].getTileType() == 4:
                W1 = random.randint(P1[0] + 1, P2[0] - 1)
                W2 = random.randint(P1[0] + 1, P2[0] - 1)

            self._grid[W1][W2] = Tile(W1, W2, 4)
            self._grid[W1][W2].setSprite(self.mountain)

        #top L
        for x in range(P1[0],P2[0] +1):
            self._grid[x][P1[1]] = Tile(x, P1[1], 3)
            self._grid[x][P1[1]].setSprite(self.street)

        for y in range(P1[1],P2[1] +1):
            self._grid[P2[0]][y] = Tile(P2[0], y, 3)
            self._grid[P2[0]][y].setSprite(self.street)

        #bottom L
        for y in range(P1[1], P2[1] + 1):
            self._grid[P1[0]][y] = Tile(P1[0], y, 3)
            self._grid[P1[0]][y].setSprite(self.street)

        for x in range(P1[0], P2[0] + 1):
            self._grid[x][P2[1]] = Tile(x, P2[1], 3)
            self._grid[x][P2[1]].setSprite(self.street)

    def allocate(self, type):
        '''allocates space for the grid of type'''
        list = []
        for moreLists in range(self._mapSize):
            list.append([])
        for theLists in list:
            for terrain in range(self._mapSize):
                if(type == None):
                    theLists.append(None)
                else:
                    theLists.append(type())


        return tuple(list)

    def getAdjacent(self, x, y):
        '''return a list of the adjacent tiles with the tile at position in tile grid'''
        adjacentList = []

        if not(x-1 <0):
           adjacentList.append(self._grid[x-1][y])
        if not (x + 1 > self._mapSize-1):
            adjacentList.append(self._grid[x + 1][y])
        if not (y - 1 < 0):
            adjacentList.append(self._grid[x][y-1])
        if not (y + 1 > self._mapSize-1):
            adjacentList.append(self._grid[x][y+1])

        return adjacentList

    # new check inbound funct
    def checkInbound(self, x, y):
        '''checks a position and returns whether it is in bound'''
        if x < 0 or x > self._mapSize or y < 0 or y > self._mapSize:
            return False
        return True

    def print_grid (self, tuple):
        '''print grid'''

        for item in tuple:
            print(item)