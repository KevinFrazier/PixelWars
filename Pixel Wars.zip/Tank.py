from tkinter import *
from Unit import Unit

'''
Tanks is a subclass of the Unit class. Therefore, it also has its own health, movement, range, attack, etc. just like
the helicopter do. The unique feature that the tank has is that it can move faster in street terrain but it cannot move
through water or mountains.

'''
class Tank(Unit):
    # type, health, damage, movement, range, x, y
    def __init__(self, x, y):
        ''' initializer '''
        Unit.__init__(self, 3, 6, 3, 3, 2, x, y)
        self.isOnStreet = False
        self.alreadyOnStreet = False

    def attack(self, otherUnit):
        ''' attack another Unit '''
        if self.getRemainingMoves() > 0:
            if self.calcAdvantage(otherUnit):
                dmg = self.getDamage() * 2
            else:
                dmg = self.getDamage()
            if otherUnit.getHealth() <= dmg:
                return True
            else:
                otherUnit.setHealth(otherUnit.getHealth() - dmg)
                return False

    def onStreet(self):
        ''' checks whether it is on a street'''
        if self.isOnStreet == True and self.alreadyOnStreet == False:
            self.setMovement(self.getMovement() + 1)
            self.alreadyOnStreet == True
            return True;
        elif self.isOnStreet == False and self.alreadyOnStreet == True:
            self.setMovement(self.getMovement() - 1)
            self.alreadyOnStreet == False
            return False

    def getOnStreet(self):
        '''returns the boolean '''
        return self.isOnStreet
    def getalreadyOnStreet(self):
        ''' returns the boolean'''
        return self.alreadyOnStreet
    def setalreadyOnSteet(self, bool):
        '''sets the value of the boolean'''
        self.alreadyOnStreet = bool
    def setStreet(self,bool):
        '''set the value of the boolean'''
        self.isOnStreet = bool

    def move(self, x, y):
        '''
        #move function (C&P from infantry)
        # click unit, click destination, if too far: show dialogue box, else: move to destination?
        # check for tile type as well to make sure not water
        '''
        if self.getRemainingMoves() > 0:
            difX = abs(self.getX() - x)
            difY = abs(self.getY() - y)
            reqMoves = difX + difY
            if reqMoves > self.getRemainingMoves():
                return False
            else:
                self.setX(x)
                self.setY(y)
                self.setRemainingMoves(self.getRemainingMoves()-reqMoves)
                return True
