from tkinter import *
'''
The purpose of the Player object is to manage the multiple units that the user controls. This also manages the cursor
of the game in order to keep track of the unit that is focused
'''

class Player(object):
    def __init__(self, playerNumber):
        ''' initializer '''
        self.playerNumber = playerNumber
        self.unitList = []
        self.isTurn = False
        self.current = 0

    def moveCursor(self,x,y):
        ''' moves cursor to a position '''
        self.cursorPositionX = x
        self.cursorPositionY = y

    def getCursor(self):
        '''gets cursor'''
        return self.cursor

    def getCursorPositionX(self):
        '''gets cursor position x'''
        return self.cursorPositionX

    def getCursorPositionY(self):
        '''get cursor position y'''
        return self.cursorPositionY

    def changeTurn(self):
        '''checks the turn of the player, then changes it'''
        if self.isTurn:
            self.isTurn = False
        else:
            self.isTurn = True

    def getNumUnits(self):
        ''' return the number of units within the list that the player controls'''
        return len(self.unitList)

    def addUnit(self, unit):
        '''add a unit in the player list'''
        self.unitList.append(unit)

    def removeUnit(self, unit):
        ''' remove a unit in the player list '''
        self.unitList.remove(unit)

    def getCurrentUnit(self):
        ''' get unit at the current index'''
        return self.unitList[self.current]

    def nextUnit(self):
        '''change the current index by +1'''
        self.current += 1

    def newTurn(self):
        '''resets the remaining moves of each unit in the list to max and starts the current index in the beginning of
            the unit list.'''
        for unit in self.unitList:
            unit.resetMoves()
        self.current = 0
