'''
The purpose of the tile class is to store the position and images as a reference as well as type check for these images.
We can also check the availability of the tile meaning that a unit from the unit class has the same position as the tile.

'''


class Tile:
    def __init__(self, x = -1, y= -1, type = -1):
        ''' Initializer '''
        self.x = x
        self.y = y #(x,y)
        self.image = None
        self._type = type
        self._available = True #checks if there is a unit there or not

    def setAvailable(self, bool):
        ''' sets the availability of the tile'''
        self._available = bool

    def isAvailable(self):
        ''' checks the availability of the tile'''
        return self._available

    def getTileType(self):
        ''' gets the type of a tile'''
        return self._type

    def setTileType(self,string):
        ''' sets the type of a tile '''
        self._type = string

    def getSprite(self):
        ''' gets the sprite image of the tile '''
        return self.image

    def setSprite(self, sprite):
        ''' sets the sprite image of the tile '''
        self.image = sprite

    def setPosition(self, x, y):
        ''' Sets the position of the tile '''
        self.x = x
        self.y = y

    def getX(self):
        ''' Sets the x position of the tile '''
        return self.x

    def getY(self):
        ''' Sets the y position of the tile '''
        return self.y

    def __str__(self):
        ''' prints the positionm, type of the tile '''
        return "[position: " + str(self.getX()) + " " + str(self.getY()) + " , type: " + str(self._type)
